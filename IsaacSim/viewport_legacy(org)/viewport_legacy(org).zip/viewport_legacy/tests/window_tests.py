# Copyright (c) 2020, NVIDIA CORPORATION.  All rights reserved.
#
# NVIDIA CORPORATION and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto.  Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA CORPORATION is strictly prohibited.
#

import omni.kit.test
from omni.kit.viewport.utility import get_active_viewport_window


class TestViewportWindowShowHide(omni.kit.test.AsyncTestCase):
    async def test_window_show_hide(self):
        # Test that multiple show-hide invocations of a window doesn't crash
        await omni.usd.get_context().new_stage_async()
        await omni.kit.app.get_app().next_update_async()

        # Show hide 10 times, and wait 60 frames between a show hide
        # This does make the test take 10 seconds, but might be  a bit
        # more representative of real-world usage when it.
        nwaits = 60
        nitrations = 10

        viewport, viewport_window = get_active_viewport_window()

        for x in range(nitrations):
            viewport_window.visible = True
            for x in range(nwaits):
                await omni.kit.app.get_app().next_update_async()
            viewport_window.visible = False
            for x in range(nwaits):
                await omni.kit.app.get_app().next_update_async()

        for x in range(nitrations):
            viewport_window.visible = False
            for x in range(nwaits):
                await omni.kit.app.get_app().next_update_async()
            viewport_window.visible = True
            for x in range(nwaits):
                await omni.kit.app.get_app().next_update_async()

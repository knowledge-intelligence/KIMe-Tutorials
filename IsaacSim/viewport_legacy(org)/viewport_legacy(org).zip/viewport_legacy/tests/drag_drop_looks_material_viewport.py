## Copyright (c) 2022, NVIDIA CORPORATION.  All rights reserved.
##
## NVIDIA CORPORATION and its licensors retain all intellectual property
## and proprietary rights in and to this software, related documentation
## and any modifications thereto.  Any use, reproduction, disclosure or
## distribution of this software and related documentation without an express
## license agreement from NVIDIA CORPORATION is strictly prohibited.
##
import os
import omni.kit.app
import omni.usd
from omni.kit.test.async_unittest import AsyncTestCase
from omni.kit import ui_test
from pxr import Sdf, UsdShade
from omni.kit.test_suite.helpers import wait_stage_loading, arrange_windows
from omni.kit.window.content_browser.test_helper import ContentBrowserTestHelper


class ZZViewportDragDropMaterialLooks(AsyncTestCase):
    # Before running each test
    async def setUp(self):
        await arrange_windows()
        await omni.usd.get_context().new_stage_async()

    # After running each test
    async def tearDown(self):
        await wait_stage_loading()

    def choose_material(self, mdl_list, excluded_list):
        for _, mdl_path, _ in mdl_list:
            mdl_name = os.path.splitext(os.path.basename(mdl_path))[0]
            if mdl_name not in excluded_list:
                return mdl_path, mdl_name

        return None, None

    async def test_l1_drag_drop_single_material_viewport_looks(self):
        from carb.input import KeyboardInput

        await ui_test.find("Content").focus()
        usd_context = omni.usd.get_context()
        stage = usd_context.get_stage()

        # create default prim
        omni.kit.commands.execute("CreatePrim", prim_path="/World", prim_type="Xform", select_new_prim=False)
        stage.SetDefaultPrim(stage.GetPrimAtPath("/World"))

        # drag to center of viewport window
        # NOTE: Material binding is only done if dropped over prim. This just creates materials as center coordinates are used
        viewport_window = ui_test.find("Viewport")
        await viewport_window.focus()
        drag_target = viewport_window.center

        # get paths
        mdl_list = await omni.kit.material.library.get_mdl_list_async()
        mdl_path1, mdl_name = self.choose_material(mdl_list, excluded_list=["OmniGlass", "OmniPBR"])

        # drag and drop items from the tree view of content browser
        async with ContentBrowserTestHelper() as content_browser_helper:
            await content_browser_helper.drag_and_drop_tree_view(mdl_path1, drag_target=drag_target)

        # wait for material to load & UI to refresh
        await wait_stage_loading()

        # verify /World/Looks type after drag/drop
        prim = stage.GetPrimAtPath("/World/Looks")
        self.assertEqual(prim.GetTypeName(), "Scope")

from .draw_tests import *
from .context_tests import *
from .create_prims import *
from .camera_tests import *
from .mouse_raycast_tests import *
# these tests must be last or test_viewport_mouse_raycast fails.
from .multi_descendents_dialog import *
from .drag_drop_multi_material_viewport import *
from .drag_drop_looks_material_viewport import *
